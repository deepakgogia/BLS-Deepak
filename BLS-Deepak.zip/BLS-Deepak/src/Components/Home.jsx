import React, { Component } from "react";
import { Link } from "react-router-dom";
import getAllData from "./../services/userservice";
import ItemContainer from "./ItemContainer";
import Modal from "react-awesome-modal";
import { connect } from 'react-redux';
import "./../styles/style.css";
import { bindActionCreators } from "redux";
import { getApiData, addTempBook } from "../actions/bookAction";

class Home extends Component {
  state = {
    totalData: {},
    searchData: "",
    showData: [],
    showAddModal: false,
    showEditModal: false,
    newBook: {
      name: "",
      year: "",
      count: 0,
      isbn: "",
      author: "",
      imagerurl: "",
      description: ""
    }
  };

  async componentDidMount() {
    var data = await this.props.GetData();
    this.setState({ totalData: data.payload, showData: data.payload });
  }

  txtChangeHandler = e => {
    const newState = { ...this.state };
    newState.searchData = e.target.value;
    newState.showData = this.state.totalData.filter(z =>
      z.name.toUpperCase().includes(newState.searchData.toUpperCase())
    );
    this.setState(newState);
  };

  btnAddBookHandler = () => {
    this.setState({
      showAddModal: !this.state.showAddModal,
      newBook: {
        name: "",
        year: "",
        count: 0,
        isbn: "",
        author: "",
        imagerurl: "",
        description: ""
      }
    });
  };
  btnEditBookHandler = () => {
    this.setState({
      showEditModal: this.state.showEditModal,
      newBook: {
        name: "",
        year: "",
        count: 0,
        isbn: "",
        author: "",
        imagerurl: "",
        description: ""
      }
    });
  };

  txtChangeEventHandler = e => {
    const { id, value } = e.currentTarget;
    let { newBook } = this.state;
    newBook[id] = value;
    this.setState({ newBook });
  };

  saveNewBook = (e) => {
    let { totalData, newBook } = this.state;
    var data = [...totalData, newBook];
    this.props.addBookNew({ data });
    this.setState({ totalData: data, showData: data });
    this.btnAddBookHandler();
  };

  updateBook = (e) => {
    let { editVisible, newBook } = e;
    var matchData = this.state.totalData.findIndex(z => z.isbn === newBook.isbn);
    this.state.totalData[matchData].count = newBook.count;
    this.state.totalData[matchData].name = newBook.name;
    this.state.totalData[matchData].description = newBook.description;
    this.state.totalData[matchData].year = newBook.year;
    this.state.totalData[matchData].author = newBook.author;
    let unMatchedResult = [...this.state.totalData.filter(z => z.isbn !== newBook.isbn)];
    const finalData = [...unMatchedResult, this.state.totalData[matchData]]
    this.setState({ totalData: finalData })
    this.btnEditBookHandler();
  }

  getCombinedElement = (name, id) => (
    <>
      <input
        className="itemInput"
        id={id}
        placeholder={name}
        onChange={e => this.txtChangeEventHandler(e)}
      />
      <br />
    </>
  );

  render() {
    const { showData, searchData } = this.state;
    return (
      <>
        <div className="divMainHeader">
          <div className="divTitle">
            <h2>Book Library System</h2>
          </div>
          <div className="divAddBook">
            <button className="addButton" onClick={this.btnAddBookHandler}>
              Add Book
            </button>
          </div>
        </div>
        <div className="inputSearch">
          <input
            className="searchBar"
            placeholder="Search here"
            value={searchData}
            onChange={this.txtChangeHandler}
          />
          <span>
            {showData.length > 0
              ? "Total Count: " + showData.length
              : "No Record Found"}
          </span>
        </div>
        <div className="divMainContainer">
          {showData &&
            showData.map(z => {
              return <ItemContainer key={z.isbn} data={z} updateData={this.updateBook} />;
            })}
        </div>

        <Modal
          visible={this.state.showAddModal}
          width="450"
          height="450"
          effect="fadeInUp"
          onClickAway={this.btnAddBookHandler}>
          <div>
            <button className="closeAddBook" onClick={this.btnAddBookHandler}>x</button>
            <form style={{ marginLeft: 40 }}>
              <h3>Add New Book</h3>
              <>
                {this.getCombinedElement("Name", "name")}
                {this.getCombinedElement("Description", "description")}
                {this.getCombinedElement("Author", "author")}
                {this.getCombinedElement("Published Year", "year")}
                {this.getCombinedElement("ISBN No.", "isbn")}
                {this.getCombinedElement("Count", "count")}
              </>
              <div className="closeButtonContainer">
                <button onClick={this.saveNewBook}>Submit</button>
                <button onClick={this.btnAddBookHandler} type="reset">Cancel</button>
              </div>
            </form>
          </div>
        </Modal>
      </>
    );
  }
}

const mapStateToProps = (state, props) => {
  return { ...state };
}

const mapDispatchToProps = (dispatch, props) => {
  return { GetData: bindActionCreators(getApiData, dispatch), addBookNew: addTempBook }
}
export default connect(mapStateToProps, mapDispatchToProps)(Home);