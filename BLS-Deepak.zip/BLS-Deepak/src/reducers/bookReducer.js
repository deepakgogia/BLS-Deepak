import { ADD_BOOK, SHOW_BOOK } from './../actions/bookAction';
export let iniState = [{
    name: 'Deepak', count: 27, year: 2010, isbn: "",
    author: "",
    imagerurl: "",
    description: ""
}]
export default (state, action) => {
    let data;
    switch (action.type) {
        case ADD_BOOK:
            return [...state, action.payload];
        case SHOW_BOOK:
            return { ...state, ...action.payload };
        default:
            return null;
    }
}
